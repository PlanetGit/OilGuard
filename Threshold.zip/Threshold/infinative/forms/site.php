<?php
///// SITES FORM /////
global $__user, $__get;
$action = isset($__get->action)?$__get->action:'';
$groups = get_option('siteGroups');
$country_list = get_option('country_list');
$site = get_site($__get->site);
$devices = $site?get_devices($site->id):false;
$templates = get_device_templates();
$return_url = http_build_query(array('manage' => 'sites', 'title' => 'Manage Sites', 'site' => $site->id));
$siteID = isset($site->id)?$site->id:'';
$pages = get_widget_pages();

foreach ($country_list as $key => $val) {
	$countries[] = array('value' => $key, 'label' => $val);
}

$fields = array(
	'id' => array(
		'label' =>  'Site ID',
		'desc' => 'global id',
		'id' => 'id',
		'type' => 'text',
		'std' => '',
		'req' => true,
		'row' => array('open' => true),
		'sh' => 2,
	),
	'name' => array(
		'label' =>  'Site Name',
		'pattern' => "^[a-zA-Z0-9 .()-]{4,32}$",
		'desc' => 'must be unique to other names',
		'id' => 'name',
		'type' => 'text',
		'std' => '',
		'req' => true,
		'row' => array('close' => true),
		'sh' => '4',
	),
	'lat' => array(
		'label' =>  '',
		'desc' => 'Latitude',
		'id' => 'lat',
		'type' => 'text',
		'std' => '',
		'row' => array('open' => true),
		'sh' => '2p4'
	),
	'lng' => array(
		'label' =>  '',
		'desc' => 'Longitude',
		'id' => 'lng',
		'type' => 'text',
		'std' => '',
		'row' => array('close' => true),
		'sh' => '2p4'
	),
	'siteGroup' => array(
		'label' =>  'Group',
		'desc' => false,
		'id' => 'siteGroup',
		'type' => 'text',
		'std' => '',
		'data' => array('list' =>$groups, 'key' => 'name'),
		'req' => true,
		'sh' => 4
	),
	'siteType' => array(
		'label' =>  'Site Type',
		'desc' => false,
		'id' => 'meta',
		'type' => 'radio',
		'options' => array(
			array('label' => 'Commercial', 'value' => 'commercial'),
			array('label' => 'Domestic', 'value' => 'domestic'),
			array('label' => 'Other', 'value' => 'other'),
		),
		'metamap' => array('site', 'type'),
		'req' => true,
		'sh' => 7
	),
	'commercialSubType' => array(
		'label' =>  'Commercial Type',
		'desc' => false,
		'id' => 'meta',
		'type' => 'radio',
		'parent' => array('id' => 'meta[site][type]', 'value' => 'commercial', 'type' => 'show'),
		'options' => array(
			array('label' => 'Hospital', 'value' => 'hospital'),
			array('label' => 'Telco', 'value' => 'telco'),
			array('label' => 'Railway', 'value' => 'railway'),
		),
		'metamap' => array('site', 'subtype'),
		'req' => true,
		'sh' => 7
	),
	'siteAdd1' => array(
		'label' =>  'Site Address',
		'desc' => 'Address',
		'id' => 'meta',
		'req' => true,
		'type' => 'text',
		'metamap' => array('site', 'address'),
		'sh' => 5
	),
	'siteAdd2' => array(
		'label' =>  false,
		'id' => 'meta',
		'type' => 'text',
		'metamap' => array('site', 'address2'),
		'sh' => 5
	),
	'siteCity' => array(
		'label' =>  true,
		'desc' => 'City',
		'id' => 'meta',
		'type' => 'text',
		'req' => true,
		'row' => array('open' => true),
		'metamap' => array('site', 'city'),
		'sh' => 3
	),
	'siteCounty' => array(
		'label' =>  true,
		'desc' => 'County',
		'id' => 'meta',
		'type' => 'text',
		'req' => true,
		'row' => array('open' => false, 'close' => false),
		'metamap' => array('site', 'county'),
		'sh' => 3
	),
	'sitePostCode' => array(
		'label' =>  true,
		'desc' => 'Post Code',
		'id' => 'meta',
		'type' => 'text',
		'row' => array('close' => true),
		'metamap' => array('site', 'postCode'),
		'sh' => 2
	),
	'siteCountry' => array(
		'label' =>  true,
		'desc' => 'Country',
		'id' => 'meta',
		'req' => true,
		'type' => 'dropdown',
		'options' => $countries,
		'std' => 'IRL',
		'metamap' => array('site', 'country'),
		'sh' => '4p4'
	),
	'company' => array(
		'label' =>  'Company',
		'desc' => 'Name',
		'id' => 'company',
		'type' => 'text',
		'req' => true,
		'sh' => 4
	),
	'companyAdd1' => array(
		'label' =>  ' ',
		'desc' => 'Address',
		'id' => 'meta',
		'req' => true,
		'type' => 'text',
		'metamap' => array('companyAddress', 'address'),
		'sh' => 5
	),
	'companyAdd2' => array(
		'label' =>  false,
		'id' => 'meta',
		'type' => 'text',
		'metamap' => array('companyAddress', 'address2'),
		'sh' => 5
	),
	'companyCity' => array(
		'label' =>  true,
		'desc' => 'City',
		'id' => 'meta',
		'type' => 'text',
		'req' => true,
		'row' => array('open' => true),
		'metamap' => array('companyAddress', 'city'),
		'sh' => 3
	),
	'companyCounty' => array(
		'label' => true,
		'desc' => 'County',
		'id' => 'meta',
		'type' => 'text',
		'req' => true,
		'row' => array('open' => false, 'close' => false),
		'metamap' => array('companyAddress', 'country'),
		'sh' => 3
	),
	'companyPostCode' => array(
		'label' =>  true,
		'desc' => 'Post Code',
		'id' => 'meta',
		'type' => 'text',
		'row' => array('close' => true),
		'metamap' => array('companyAddress', 'postCode'),
		'sh' => 2
	),
	'companyCountry' => array(
		'label' =>  true,
		'desc' => 'Country',
		'id' => 'meta',
		'req' => true,
		'type' => 'dropdown',
		'options' => $countries,
		'std' => 'IRL',
		'metamap' => array('companyAddress', 'country'),
		'sh' => '4p4'
	),
	'khName' => array(
		'label' =>  'Primary Key Holder',
		'desc' => 'Name',
		'id' => 'meta',
		'type' => 'text',
		'req' => true,
		'metamap' => array('keyHolder', 'name'),
		'sh' => 5
	),
	'khPhone' => array(
		'label' =>  ' ',
		'desc' => 'Phone',
		'id' => 'meta',
		'type' => 'phone',
		'req' => true,
		'metamap' => array('keyHolder', 'phone'),
		'row' => array('open' => true),
		'sh' => '3p2'
	),
	'khEmail' => array(
		'label' =>  ' ',
		'desc' => 'Email',
		'id' => 'meta',
		'req' => true,
		'metamap' => array('keyHolder', 'email'),
		'type' => 'email',
		'row' => array('close' => true),
		'sh' => '4p2'
	),
	'khAdd1' => array(
		'label' =>  ' ',
		'desc' => 'Address',
		'id' => 'meta',
		'req' => false,
		'metamap' => array('keyHolder', 'address'),
		'type' => 'text',
		'sh' => 5
	),
	'khAdd2' => array(
		'label' =>  false,
		'id' => 'meta',
		'metamap' => array('keyHolder', 'address2'),
		'type' => 'text',
		'sh' => 5
	),
	'khCity' => array(
		'label' =>  true,
		'desc' => 'City',
		'id' => 'meta',
		'metamap' => array('keyHolder', 'city'),
		'type' => 'text',
		'req' => false,
		'row' => array('open' => true),
		'sh' => 3
	),
	'khCounty' => array(
		'label' =>  true,
		'desc' => 'County',
		'id' => 'meta',
		'metamap' => array('keyHolder', 'county'),
		'type' => 'text',
		'req' => false,
		'row' => array('open' => false, 'close' => false),
		'sh' => 3
	),
	'khPostCode' => array(
		'label' =>  true,
		'desc' => 'Post Code',
		'id' => 'meta',
		'metamap' => array('keyHolder', 'postcode'),
		'type' => 'text',
		'row' => array('close' => true),
		'sh' => 2
	),
	'khCountry' => array(
		'label' =>  true,
		'desc' => 'Country',
		'id' => 'meta',
		'req' => true,
		'metamap' => array('keyHolder', 'country'),
		'type' => 'dropdown',
		'options' => $countries,
		'std' => 'IRL',
		'sh' => '4p4'
	),
	'kh2Name' => array(
		'label' =>  'Secondary Key Holder',
		'desc' => 'Name',
		'id' => 'meta',
		'type' => 'text',
		'metamap' => array('keyHolder2', 'name'),
		'sh' => 5
	),
	'kh2Phone' => array(
		'label' =>  ' ',
		'desc' => 'Phone',
		'id' => 'meta',
		'type' => 'phone',
		'metamap' => array('keyHolder2', 'phone'),
		'row' => array('open' => true),
		'sh' => '3p2'
	),
	'kh2Email' => array(
		'label' =>  ' ',
		'desc' => 'Email',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'email'),
		'type' => 'email',
		'row' => array('close' => true),
		'sh' => '4p2'
	),
	'kh2Add1' => array(
		'label' =>  ' ',
		'desc' => 'Address',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'address'),
		'type' => 'text',
		'sh' => 5
	),
	'kh2Add2' => array(
		'label' =>  false,
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'address2'),
		'type' => 'text',
		'sh' => 5
	),
	'kh2City' => array(
		'label' =>  true,
		'desc' => 'City',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'city'),
		'type' => 'text',
		'row' => array('open' => true),
		'sh' => 3
	),
	'kh2County' => array(
		'label' =>  true,
		'desc' => 'County',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'county'),
		'type' => 'text',
		'row' => array('open' => false, 'close' => false),
		'sh' => 3
	),
	'kh2PostCode' => array(
		'label' =>  true,
		'desc' => 'Post Code',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'postcode'),
		'type' => 'text',
		'row' => array('close' => true),
		'sh' => 2
	),
	'kh2Country' => array(
		'label' =>  true,
		'desc' => 'Country',
		'id' => 'meta',
		'metamap' => array('keyHolder2', 'country'),
		'type' => 'dropdown',
		'options' => $countries,
		'std' => 'IRL',
		'sh' => '4p4'
	),
	'installed' => array(
		'label' =>  'Installed Date',
		'desc' => false,
		'id' => 'installed',
		'type' => 'date',
		'sh' => '2p6',
		'req' => true,
		'row' => array('open' => true)
	),
	'commissioned' => array(
		'label' =>  'Commissioned Date',
		'desc' => false,
		'id' => 'meta',
		'type' => 'date',
		'sh' => '2p6',
		'metamap' => array('site', 'commissioned'),
		'row' => array('close' => true)
	),
	'theftTd' => array(
		'label' =>  'Theft',
		'desc' => 'Threshold',
		'id' => 'meta',
		'type' => 'number',
		'metamap' => array('thresholds', 'theft'),
		'row' => array('open' => true),
		'sh' => '1p7',
		'std' => 6
	),
	'theftTdAux' => array(
		'label' =>  '',
		'desc' => 'Aux',
		'id' => 'meta',
		'type' => 'number',
		'metamap' => array('thresholds', 'theftAux'),
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 6
	),
	'theftTdPeriod' => array(
		'label' =>  '',
		'desc' => 'Period',
		'id' => 'meta',
		'type' => 'number',
		'metamap' => array('thresholds', 'theftPeriod'),
		'row' => array('close' => true),
		'sh' => '1p7',
		'std' => 0
	),
	'spillTd' => array(
		'label' =>  'Spill',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'spill'),
		'type' => 'number',
		'row' => array('open' => true),
		'sh' => '1p7',
		'std' => 0
	),
	'spillTdAux' => array(
		'label' =>  '',
		'desc' => 'Aux',
		'id' => 'meta',
		'metamap' => array('thresholds', 'spillAux'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 0
	),
	'spillTdPeriod' => array(
		'label' =>  '',
		'desc' => 'Period',
		'id' => 'meta',
		'metamap' => array('thresholds', 'spillPeriod'),
		'type' => 'number',
		'row' => array('close' => true),
		'sh' => '1p7',
		'std' => 0
	),
	'fillTd' => array(
		'label' =>  'Fill',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'fill'),
		'type' => 'number',
		'row' => array('open' => true),
		'sh' => '1p7',
		'std' => 6
	),
	'fillTdPeriod' => array(
		'label' =>  '',
		'desc' => 'Period',
		'id' => 'meta',
		'metamap' => array('thresholds', 'fillPeriod'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 0
	),
	'waterTd' => array(
		'label' =>  'Water Detect',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'waterDetect'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 992
	),
	'waterTdPeriod' => array(
		'label' =>  '',
		'desc' => 'Period',
		'id' => 'meta',
		'metamap' => array('thresholds', 'waterDetectPeriod'),
		'type' => 'number',
		'row' => array('close' => true),
		'sh' => '1p7',
		'std' => 0
	),
	'lowLevelTd' => array(
		'label' =>  'Low Level',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'lowLevel'),
		'type' => 'number',
		'row' => array('open' => true),
		'sh' => '1p7',
		'std' => 182
	),
	'overfillTd' => array(
		'label' =>  'Overfill',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'overfill'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 864
	),
	'auxTd' => array(
		'label' =>  'Aux',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'aux'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'sh' => '1p7',
		'std' => 65535
	),
	'modeOfOperationTd' => array(
		'label' =>  'Mode Of Operation',
		'desc' => 'Threshold',
		'id' => 'meta',
		'metamap' => array('thresholds', 'modeOfOperation'),
		'type' => 'number',
		'row' => array('close' => true),
		'sh' => '2p3',
		'std' => 0
	),
	'capacity' => array(
		'label' =>  'Capacity',
		'desc' => 'integer in liters',
		'id' => 'capacity',
		'type' => 'number',
		'std' =>1500,
		'req' => true,
		'sh' => 2
	),
	'fuelType' => array(
		'label' =>  'Fuel Type',
		'desc' => false,
		'id' => 'fuelType',
		'type' => 'radio',
		'options' => array(
			array('label' => 'Diesel', 'value' => 'diesel'),
			array('label' => 'Kerosene', 'value' => 'kerosene'),
		),
		'row' => array('open' => true),
		'sh' => '2p4'
	),
	'auxInput' => array(
		'label' =>  'Auxiliary Input',
		'desc' => false,
		'id' => 'auxInput',
		'type' => 'radio',
		'options' => array(
			array('label' => 'None', 'value' => 'none'),
			array('label' => 'Battery', 'value' => 'battery'),
			array('label' => 'Pump', 'value' => 'pump'),
			array('label' => 'Generator', 'value' => 'generator'),
		),
		'row' => array('close' => true),
		'sh' => '5'
	),
	'tankProfile' => array(
		'label' =>  'Tank Profile',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('tank', 'profile'),
		'type' => 'radio',
		'options' => array(
			array('label' => 'Square', 'value' => 'square'),
			array('label' => 'Rectangular', 'value' => 'rectangular'),
			array('label' => 'Cylinder Vertical', 'value' => 'cylinder-vertical'),
			array('label' => 'Cylinder Horizontal', 'value' => 'cylinder-horizontal'),
		),
		'req' => true,
		'sh' => '6p6'
	),
	'tankLength' => array(
		'label' =>  'Length',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('tank', 'length'),
		'type' => 'number',
		'row' => array('open' => true),
		'req' => true,
		'sh' => '1p6'
	),
	'tankWidth' => array(
		'label' =>  'Width',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('tank', 'width'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'req' => true,
		'sh' => '1p6'
	),
	'tankHeight' => array(
		'label' =>  'Height',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('tank', 'height'),
		'type' => 'number',
		'row' => array('open' => false, 'close' => false),
		'req' => true,
		'sh' => '1p6'
	),
	'probeLength' => array(
		'label' =>  'Probe Length',
		'desc' => false,
		'id' => 'meta',
		'type' => 'number',
		'metamap' => array('tank', 'probeLength'),
		'parent' => array('id' => 'meta[tank][height]', 'value' => 'max', 'type' => 'limit'),
		'row' => array('close' => true),
		'req' => true,
		'sh' => '1p6'
	),
	'productId' => array(
		'label' =>  'Product Id',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('site', 'productId'),
		'type' => 'text',
		'row' => array('open' => true),
		'sh' => 2
	),
	'productName' => array(
		'label' =>  'Product Name',
		'desc' => false,
		'id' => 'meta',
		'metamap' => array('site', 'productName'),
		'type' => 'text',
		'row' => array('close' => true),
		'req' => true,
		'sh' => 5
	),
	'chartWeek' => array(
		'label' =>  'Charts',
		'desc' => 'Week',
		'id' => 'meta',
		'metamap' => array('chart', 'Week'),
		'type' => 'url',
		'row' => array('open' => true),
		'req' => true,
		'sh' => '7p4',
		'std' => 'https://jolicharts.com/embed/chart/e14fda11840d5fe16195b7a40e46ce9d/41e3d6cda064d1c73976545d5f3e76bb?SiteId='.$siteID,
	),
	'chartMonth' => array(
		'label' =>  true,
		'desc' => 'Month',
		'id' => 'meta',
		'metamap' => array('chart', 'Month'),
		'type' => 'url',
		'row' => array('open' => false, 'close' => false),
		'req' => true,
		'sh' => '7p4',
		'std' => 'https://jolicharts.com/embed/chart/e14fda11840d5fe16195b7a40e46ce9d/a41e0e5acc6cdc5c667fc9c1e851b3c0?SiteId='.$siteID,
	),
	'chartQuarter' => array(
		'label' =>  true,
		'desc' => 'Quarter',
		'id' => 'meta',
		'metamap' => array('chart', 'Quarter'),
		'type' => 'url',
		'row' => array('open' => false, 'close' => false),
		'req' => true,
		'sh' => '7p4',
		'std' => 'https://jolicharts.com/embed/chart/e14fda11840d5fe16195b7a40e46ce9d/e67cae95a7772587ee27784e2454483f?SiteId='.$siteID,
	),
	'chartYear' => array(
		'label' =>  true,
		'desc' => 'Year',
		'id' => 'meta',
		'metamap' => array('chart', 'Year'),
		'type' => 'url',
		'row' => array('close' => true),
		'req' => true,
		'sh' => '7p4',
		'std' => 'https://jolicharts.com/embed/chart/e14fda11840d5fe16195b7a40e46ce9d/de3614bb4e9a82a9fd480f8d4936da33?SiteId='.$siteID,
	),
);

$charts = array('chartWeek', 'chartMonth', 'chartQuarter', 'chartYear');
$siteType = array('siteType', 'commercialSubType');
$dates = array('installed', 'commissioned', 'capacity');
$tank = array('fuelType', 'auxInput', 'tankProfile', 'tankLength', 'tankWidth', 'tankHeight', 'probeLength');
$theftTd = array('theftTd', 'theftTdAux', 'theftTdPeriod');
$spillTd = array('spillTd', 'spillTdAux', 'spillTdPeriod');
$fillTd = array('fillTd', 'fillTdPeriod');
$waterTd = array('waterTd', 'waterTdPeriod');
$address = array('siteAdd1', 'siteAdd2', 'siteCity', 'siteCounty', 'sitePostCode', 'siteCountry');
$companyAddress = array('company', 'companyAdd1', 'companyAdd2', 'companyCity', 'companyCounty', 'companyPostCode', 'companyCountry');
$keyHolder = array('khName', 'khPhone', 'khEmail', 'khAdd1', 'khAdd2', 'khCity', 'khCounty', 'khPostCode', 'khCountry');
$keyHolder2 = array('kh2Name', 'kh2Phone', 'kh2Email', 'kh2Add1', 'kh2Add2', 'kh2City', 'kh2County', 'kh2PostCode', 'kh2Country');
$product = array('productId', 'productName');

$p->pages = array(
	'page1' => array('id', 'name', 'siteGroup', $address, 'lat', 'lng'),
	'page2' => array($dates, $siteType, $charts),
	'page3' => array($tank, $theftTd, $spillTd, $fillTd, $waterTd, 'lowLevelTd', 'overfillTd', 'auxTd', 'modeOfOperationTd'),
	'page4' => array($product, $companyAddress),
	'page5' => array($keyHolder),
	'page6' => array($keyHolder2),
);
$css->h->s = 8;
$css->h->p = 0;
$css->v->s = 7;
$css->v->p = 5;

// DISPLAY FORM
?>
<form id="site" action="" class="boxes sh10p5 sv8p2 sitRight" style="margin:0px!important; height:100%;">
	<input type="hidden" name="action" id="action" value="update_site" />
	<?php if ($site) { ?>
    <input type="hidden" id="oid" name="oid" value="<?php echo $site->id; ?>" />
    <input type="hidden" id="oname" name="oname" value="<?php echo $site->name; ?>" />
    <?php } ?>
    <div class="paged outer <?php i_class($css); ?>" data-paged='{"dir":"x"}' style="margin:0px!important;">
    	<div class="paged scroll <?php i_class($css); ?>" data-paged='{"dir":"x"}'>
    	<div class="paged wrap <?php i_class($css); ?>">
    	<?php 
			$h->h = $css->h;
			$v->v = $css->v; 
		?>
    	<div class="paged slide <?php i_class($v); ?>">
		<?php
		$saved = $action !== 'after_save'?true:false;
        foreach ($p->pages as $key => $page) {
            echo '<div class="page '.$key.' '.i_class($css, 1, false).'">';
            foreach($page as $pageField) {
				if (gettype($pageField) == 'array') {
					foreach ($pageField as $pf) {
						$field = $fields[$pf];
						$val = $site?   (isset($field['metamap']) ? ( map_meta($field['metamap'], $site->meta->{$field['metamap'][0]}) ) : $site->{$field['id']} )   :NULL;
						i_field($field, $val, $saved);
					}
				}else{
					$field = $fields[$pageField];
					$val = $site?(isset($field['metamap'])?(map_meta($field['metamap'], $site->meta->{$field['metamap'][0]})):$site->{$field['id']}):NULL;
					i_field($field, $val, $saved);
				}
            }
			echo '</div>';
        }
        ?>
    	</div>
        <div style="clear:both;"></div>
        </div>
        </div>
    </div>
    <div style="clear:both;"></div>
    <div class="paged foot <?php i_class($h); ?> sv0p4" style="margin:0px!important;">
    	<?php if ($action !== 'after_save') { ?>
    	<input id="submit" type="submit" value="Save Site">
        <?php } ?>
   	</div>
    <div class="paged tools sh2p5 sv8p1 skip0p1 sitRight" style="clear:right; margin:0px!important; overflow:hidden; overflow-y:auto; padding-right:21px; margin-right:-21px!important;">
    	<?php
			$val = isset($site)?$site->active:NULL;
			$live = ($action == 'after_save' || !user_can('activate_sites'))?'dead':'live';
		?>
        <div class="row switch-row">
            <div class="activate switch" data-input="active">
                <label for="active"></label>
                <div class="switch-groove">
                    <div class="switch-btn" data-state="<?php echo $live; ?>" data-labels='{"on":"Active", "off":"Inactive"}'></div>
                    <input type="hidden" id="active" name="active" value="<?php echo $val; ?>">
                </div>
            </div>
      	</div>
        <?php if(user_can('send_thresholds') && isset($site->id)) { ?>
        	<div class="row"><input class="red" data-site="<?php echo $site->id; ?>" id="send_thresholds" type="button" value="Send Thresholds"></div>
        <?php } ?>
        <?php if(user_can('manage_site_page')) {
			$_pages[] = array('icon' => 'site', 'value' => 0, 'label' => 'Default');
			$_pages[] = array('icon' => 'meter', 'value' => 'flow', 'label' => 'Flow Meter');
			if(isset($pages)) {
				foreach($pages as $page) {
					$_pages[] = array('icon' => $page->icon, 'value' => $page->id, 'label' => $page->label);
				}
			}
        	$site_page = array(
                'label' =>  'Site Page',
				'desc' => false,
                'id' => 'meta',
                'metamap' => array('page', 'id'),
                'type' => 'dropdown',
                'options' => $_pages,
                'std' => 0,
                'sh' => '2p1',
				'row' => false,
            );
			$val = isset($site->meta->page->id)?$site->meta->page->id:NULL;
			?>
                <div class="row">
            		<?php i_field($site_page, $val, $saved); ?>
                </div>
        <?php } ?>
        <?php if(user_can('manage_site_devices')) { ?>
        	<?php foreach($devices as $device) { ?>
        		<div class="row"><input class="black whiteF" data-device="<?php echo $device->device; ?>" data-name="<?php echo $device->name; ?>" id="edit_device" type="button" value="<?php echo $device->name; ?>"></div>
          	<?php } ?>
            <?php foreach($templates as $template) { ?>
        		<div class="row"><input class="orange whiteF" data-template="<?php echo $template->id; ?>" data-name="<?php echo $template->name; ?>" id="add_device" type="button" value="Add <?php echo $template->name; ?>"></div>
          	<?php } ?>
        <?php } ?>
    </div>
</form>
<script type="text/javascript">
	$(document).ready(function() {
		var _site = $(this).find('form#site').first();
		_site.objs = {};
		<?php if(user_can('manage_devices')) { ?>
			$('#site #edit_device').click(function() {
				var device = $(this).data('device');
				var name = $(this).data('name');
				openPage({form:'device', title:'<?php echo $site->name; ?> '+name, site:'<?php echo $site->id; ?>', device:device, return:'<?php echo $return_url; ?>'});
			});
			$('#site #add_device').click(function() {
				var template = $(this).data('template');
				var name = $(this).data('name');
				openPage({form:'device', title:'<?php echo $site->name; ?> New '+name, template:template, site:'<?php echo $site->id; ?>', return:'<?php echo $return_url; ?>'});
			});
		<?php } ?>
		var tz = {}
		_site.objs[tz] = tz;
		<?php if($site) { ?>
			<?php if(isset($site->meta->timeZone)) { ?>
			tz = <?php echo json_encode($site->meta->timeZone); ?>;
			<?php } ?>
			//GET AND SET TIMEZONE FROM LAT LONG 
			site.lat = <?php echo $site->lat; ?>;
			site.lng = <?php echo $site->lng; ?>;
			site.get_tz = function() {
				var stamp = times.now();
				var response = {};
				var dif = moment.utc().subtract('days', 14).valueOf()/1000 > tz.stamp;
				if(typeof(site.lat) !== 'undefined' && typeof(site.lng) !== 'undefined' && site.lat !== '' && site.lng !== '') {
					var update = (typeof(tz) == 'undefined' || $.isEmptyObject(tz)) ? true : false;
					if(update || dif) {
						var gurl = 'https://maps.googleapis.com/maps/api/timezone/json?key=AIzaSyAm0dQfXTyAzXqo7_Q0wiNhh6byBZ53K4U&location='+site.lat+','+site.lng+'&timestamp='+stamp+'&sensor=false';
						$.getJSON(gurl, function( data ) {
							$.each(data, function(key, val) {
								update = tz[key] !== val ? true : update;
							});
							data.stamp = Math.floor(stamp);
							data.totalOffset = data.dstOffset + data.rawOffset;
							if(update) {
								$.each(data, function(key, val) {
									if(key !== 'status') {
										var name = 'meta[timeZone]['+key+']';
										$('form#site').append('<input type="hidden" id="'+name+'" name="'+name+'" value="'+val+'">');
									}
								});
							}
						});
					}
				}
			}
			site.get_tz();
		<?php } ?>
		
		var depend = {};
		$('.depends').each(function(i, element) {
			var parent = $(this).data('parent');
			depend[i] = {};
			depend[i].e = $(this);
			depend[i].p = parent;
			depend[i].html = $(this).html();
			$('input[name="'+parent.id+'"]').on("change", function() {
				switch (depend[i].p.type) {
					case 'show':
						if ($(this).val() == depend[i].p.value) {
							depend[i].e.html(depend[i].html);
							depend[i].e.show();
						}else{
							depend[i].e.html('');
							depend[i].e.hide();
						}
					break;
					case 'limit':
						depend[i].e.find('input').first().attr(depend[i].p.value, $('input[name="'+parent.id+'"]').val());
					break;
				}
			})
			switch (depend[i].p.type) {
				case 'show':
					if ($('input[name="'+parent.id+'"]').val() == depend[i].p.value) {
						depend[i].e.html(depend[i].html);
						depend[i].e.show();
					}else{
						depend[i].e.html('');
						depend[i].e.hide();
					}
				break;
				case 'limit':
					var input = depend[i].e.find('input').first();
					input.attr(depend[i].p.value, $('input[name="'+parent.id+'"]').val());
				break;
			}
		});
		$('#site #send_thresholds').click(function() {
			var tbtn = $(this);
			tbtn.unbind('click');
			var site_id = $(this).data('site');
			var ltext = $(this).val();

			(async () => {

				// get the open URL by site's ID.
				var openUrl = await findDataFromSiteID( site_id );

				var w = window.open( openUrl, 'popupWindow', 'width=300, height=300' );
				var win = {content:{}};
				win.content = $(w.document.body);
				win.loaded = function() {
					if (win.content) {
						tbtn.addClass('green');
						tbtn.removeClass('red');
						tbtn.css('color', 'white');
						tbtn.val('Thresholds Sent');
						makeCall({action:'user_actions', user_action:'send_tresholds', ptype:'post', description:'sent thresholds from site form', uid:'<?php echo $site->id; ?>'});
					}
				}
				win.timed = function() {
					setTimeout(function() {
						if(w.closed) {
							win.loaded();
						}else{
							win.timed();
						}
					}, 200);
				}
				win.timed();
			})();
		});

		/**
		 * Getting the URL by site's ID.
		 * CREATED DATE: 2019-05-06
		 * 
		 * @return {TEXT}
		 */
		async function findDataFromSiteID( siteID ) {

			try {
				var xml = await $.get('threshold.xml');
				if ( typeof xml == 'string' ) {
					alert('There is no XML file on the server.');
					return;
				}

				var jsonXML = $.xml2json(xml);
				var siteURL = '';

				$.map( jsonXML.server, function( val ) {

					if ( parseInt(val.from) <= siteID && siteID <= parseInt(val.to) ) {
						siteURL = val.url;
					}
				});	
				
			} catch (error) {
				console.log(error);
			}

			if ( siteURL == '' ) 
				return 'http://ogthresholds.mydeviceshark.net:9002/client/threshold.html?id='+siteID+'&remote=1';

			var url = 'http://'+siteURL+'/client/threshold.html?id='+siteID+'&remote=1';
			return url;
		}

		function fixMenu(s) {
			if(s.oid) {
				var sgroup = $('.item#site-'+s.oid).parent();
				$('.item#site-'+s.oid).remove();
				if (sgroup.find('.item').length < 1) {
					var gh = $('.head.'+sgroup.attr('id')).first();
					sgroup.remove();
					gh.remove();
				}
			}
			var str = '<div class="item site clickable" id="site-'+s.id+'" data-id="'+s.id+'" data-name="'+s.name+'">';
			var sname = user.level == 0?s.name+' ('+s.id+')':s.name;
			str += '<div class="icon site adjust">'+sname+'</div></div>';
			var grouped;
			var section;
			if ($('#g-'+s.group).length !== 0) {
				grouped = $('#g-'+s.group).first();
				section = $('.section#'+grouped.data('for')).first();
				section.prepend(str);
				var i = section.find('.item.site').first();
				i.i_setup = fun.i_setup;
				i.i_setup();
			}else{
				var i = $('.site.list .head').length+1;
				str = '<div class="head group-'+i+'" id="g-'+s.group+'" data-for="group-'+i+'">'+s.group+'</div><div style="clear:both;"></div><div class="section" id="group-'+i+'">'+str+'</div><div style="clear:both;"></div>';
				var li = $('.site.list .tile-content').first();
				li.prepend(str);
				var h = li.find('.head').first();
				section = li.find('.section').first();
				h.i_head = fun.i_head;
				h.i_head();
				section.find('.item.site').each(function() {
					var i = $(this);
					i.i_setup = fun.i_setup;
					i.i_setup();
				});
			}
			setTimeout(function() {
				$('#g-'+s.group).first().click();
			}, 500);
		}
		$('#site').submit(function() {
			var form = jQuery(this);
			var formdata = form.serialize();
			$.ajax({  
				url: '',
				type: 'post',
				dataType: 'json', 
				data: formdata,
				beforeSend: function(xhr) {
					loaderInit({wrap:'#site', btn:'#submit'});
						if ($('#oid').val() && $('#oid').val() !== $('#id').val()) {
							var confirmed = confirm('Are you sure you wish to change this sites id from '+$('#oid').val()+' to '+$('#id').val()+'?');
							if (!confirmed) {
								xhr.abort();
								alert("the site was not updated");
								$('#id').val($('#oid').val());
								$('#loader').remove();
							}
						}
					},
				success: function(data) {
					r = data.response;
					$('#loader').remove();
					if (r.success) {
						var site_id = r.id;
						var site_name = r.name;
						$('#form').slideUp(800, function() {
							$('#form').empty();
							setTitle('Updated '+site_name);		
							$('#form').load('?form=site&action=after_save&site='+site_id, function() {
								$('#form').slideDown(800);
								fixMenu(r);
							});
						});
					}else{
						alert('Failure: '+r.msg);
					}
					if (typeof(r.console) !== 'undefined') {
						console.log(r.console);
					}
				}   
			});
			return false;
		});
		_site.on('remove', function() {
			_site.cleanUp();
		});
	});
</script>